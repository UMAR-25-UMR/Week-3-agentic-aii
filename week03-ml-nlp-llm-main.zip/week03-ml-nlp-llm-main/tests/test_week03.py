from src.week03 import clean_text, phase1_classification, semantic_search


def test_preprocessing():
    assert clean_text("  I NEED HELP!!!  ") == "i need help"
    assert clean_text("Hello,    World!") == "hello world"
    assert clean_text(" Machine Learning... ") == "machine learning"


def test_classifier_predicts_known_labels():
    classifier = phase1_classification()
    assert classifier.predict(["This course is excellent"])[0] in {"positive", "negative"}


def test_search_ranking_with_fake_embeddings():
    import numpy as np

    class FakeModel:
        def encode(self, texts):
            return np.array([[1., 0.] if "fees" in s else [0., 1.] for s in texts])

    docs = ["Pay fees", "Visit library"]
    results = semantic_search("fees", FakeModel(), documents=docs, top_k=1)
    assert results[0][0] == "Pay fees"
