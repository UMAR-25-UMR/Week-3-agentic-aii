"""Week 03 — Machine Learning, NLP and LLM foundations.
Run: python -m src.week03 --phase all
"""
import argparse
import re
from pathlib import Path

DATA = [
    ("I love this course", "positive"),
    ("This course is excellent", "positive"),
    ("Amazing learning experience", "positive"),
    ("I really enjoyed this lesson", "positive"),
    ("This is fantastic and helpful", "positive"),
    ("I am happy with this course", "positive"),
    ("The lessons are clear and great", "positive"),
    ("Wonderful teaching and support", "positive"),
    ("I hate this course", "negative"),
    ("This course is terrible", "negative"),
    ("Very bad learning experience", "negative"),
    ("I did not enjoy this lesson", "negative"),
    ("This is horrible and confusing", "negative"),
    ("I am unhappy with this course", "negative"),
    ("The lessons are poor and boring", "negative"),
    ("Awful teaching and support", "negative"),
]

DOCUMENTS = [
    "Students can register courses through the student portal.",
    "The examination office publishes examination schedules.",
    "The finance office handles tuition fee issues.",
    "The library provides digital research resources.",
    "Students can reset their passwords through the account recovery page.",
    "Technical support helps with login errors and portal problems.",
]


def clean_text(text: str) -> str:
    """Normalize case, punctuation and repeated whitespace."""
    text = text.strip().lower()
    text = re.sub(r"[^\w\s]", "", text)
    return re.sub(r"\s+", " ", text)


def phase1_classification():
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.linear_model import LogisticRegression
    from sklearn.metrics import accuracy_score, classification_report
    from sklearn.model_selection import train_test_split
    from sklearn.pipeline import Pipeline

    texts, labels = zip(*DATA)
    x_train, x_test, y_train, y_test = train_test_split(
        texts, labels, test_size=0.25, random_state=42, stratify=labels
    )
    classifier = Pipeline([
        ("tfidf", TfidfVectorizer()),
        ("model", LogisticRegression(max_iter=1000, random_state=42)),
    ])
    classifier.fit(x_train, y_train)  # Training learns from labeled examples.
    predictions = classifier.predict(x_test)  # Inference predicts unseen examples.
    print("\n=== PHASE 1: TEXT CLASSIFICATION ===")
    print("Training examples:", len(x_train), "Testing examples:", len(x_test))
    print("Accuracy:", round(accuracy_score(y_test, predictions), 4))
    print(classification_report(y_test, predictions, zero_division=0))
    for text in ["I love this amazing course", "This lesson is terrible"]:
        print(f"New text: {text!r} -> {classifier.predict([text])[0]}")
    return classifier


def phase2_preprocessing():
    print("\n=== PHASE 2: TEXT PREPROCESSING ===")
    samples = ["  I NEED HELP!!!  ", "Hello,    World!", "  Machine Learning is FUN... "]
    for item in samples:
        print(f"Before: {item!r} | After: {clean_text(item)!r}")


def phase3_tokenization():
    from transformers import AutoTokenizer

    print("\n=== PHASE 3: TOKENIZATION ===")
    sentence = "Large language models are powerful."
    tokenizers = {}
    for name in ("bert-base-uncased", "gpt2"):
        tokenizer = AutoTokenizer.from_pretrained(name)
        tokens = tokenizer.tokenize(sentence)
        ids = tokenizer.encode(sentence, add_special_tokens=True)
        print(f"Tokenizer: {name}")
        print("Tokens:", tokens)
        print("Token IDs:", ids)
        print("Decoded:", tokenizer.decode(ids, skip_special_tokens=True))
        print("Token count (without special tokens):", len(tokenizer.encode(sentence, add_special_tokens=False)))
        if name == "bert-base-uncased":
            print("Special tokens:", tokenizer.cls_token, tokenizer.sep_token)
            print("Special token IDs:", tokenizer.cls_token_id, tokenizer.sep_token_id)
        tokenizers[name] = tokenizer
    return tokenizers


def get_embedding_model():
    from sentence_transformers import SentenceTransformer
    return SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2")


def phase4_embeddings(model=None):
    from sklearn.metrics.pairwise import cosine_similarity
    print("\n=== PHASE 4: EMBEDDINGS AND SIMILARITY ===")
    model = model or get_embedding_model()
    sentences = ["How do I reset my password?", "I forgot my password.", "The weather is very hot today."]
    vectors = model.encode(sentences)
    related = float(cosine_similarity([vectors[0]], [vectors[1]])[0, 0])
    unrelated = float(cosine_similarity([vectors[0]], [vectors[2]])[0, 0])
    print("Embedding shape:", vectors.shape)
    print("Password vs password similarity:", round(related, 4))
    print("Password vs weather similarity:", round(unrelated, 4))
    print("Interpretation: higher cosine similarity suggests closer semantic meaning; scores are not probabilities.")
    return model


def semantic_search(query, model, documents=DOCUMENTS, top_k=3, document_embeddings=None):
    from sklearn.metrics.pairwise import cosine_similarity
    if document_embeddings is None:
        document_embeddings = model.encode(documents)
    query_vector = model.encode([query])
    scores = cosine_similarity(query_vector, document_embeddings)[0]
    ranked = sorted(zip(documents, scores), key=lambda pair: float(pair[1]), reverse=True)
    return ranked[:top_k]


def phase5_search(model=None):
    print("\n=== PHASE 5: SEMANTIC SEARCH ===")
    model = model or get_embedding_model()
    document_embeddings = model.encode(DOCUMENTS)  # Stored once and reused for each query.
    for query in ["Where can I register for classes?", "How do I pay tuition fees?", "I cannot access my account"]:
        print("\nQuery:", query)
        for document, score in semantic_search(query, model, document_embeddings=document_embeddings):
            print(f"  {float(score):.4f} -> {document}")


def main():
    parser = argparse.ArgumentParser(description="Week 03 practical assignment")
    parser.add_argument("--phase", choices=["all", "1", "2", "3", "4", "5"], default="all")
    args = parser.parse_args()
    steps = {"1": phase1_classification, "2": phase2_preprocessing,
             "3": phase3_tokenization, "4": phase4_embeddings, "5": phase5_search}
    if args.phase == "all":
        for step in steps.values():
            step()
    else:
        steps[args.phase]()


if __name__ == "__main__":
    main()
