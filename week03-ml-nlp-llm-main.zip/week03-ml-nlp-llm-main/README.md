# Week 03 — Machine Learning, NLP & LLM Foundations

Python practical assignment based on the provided **Week 03.docx** and **Week 03 Checklist (2).docx**. The source document calls its activities Phase 01–06; this submission organizes the five practical topics into functions and includes quality/submission evidence as the sixth checklist section.

## Folder structure

```text
Week03_ML_NLP_LLM/
├── src/
│   ├── __init__.py
│   └── week03.py
├── tests/
│   └── test_week03.py
├── evidence/
│   ├── phase1_output.txt
│   ├── phase2_output.txt
│   └── pytest_output.txt
├── requirements.txt
└── README.md
```

## Setup (Windows PowerShell)

Python 3.10+ recommended. Open PowerShell inside this folder:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
python -m src.week03 --phase all
python -m pytest -v
```

**First run:** `bert-base-uncased`, `gpt2` and `sentence-transformers/all-MiniLM-L6-v2` download pretrained model files from Hugging Face. Internet access and sufficient disk space are required. Later runs can use cached files. No paid API key is needed.

Run a single phase if desired: `python -m src.week03 --phase 1` (or `2`, `3`, `4`, `5`).

## Checklist mapping

| Checklist | Implementation |
| --- | --- |
| 1. Text Classification | `phase1_classification()` — labeled dataset, TF-IDF, stratified train/test split, LogisticRegression, predictions, accuracy, classification report |
| 2. Text Preprocessing | `clean_text()` and `phase2_preprocessing()` — trim, lowercase, collapse whitespace, remove punctuation, test multiple strings |
| 3. Tokenization | `phase3_tokenization()` — BERT and GPT-2 pretrained tokenizers, tokens, IDs, decode, count comparison, special tokens |
| 4. Embeddings | `phase4_embeddings()` — MiniLM sentence embeddings, cosine similarity of related/unrelated sentences, interpretation |
| 5. Semantic Search | `semantic_search()` and `phase5_search()` — embedded documents, query embedding, cosine similarity, ranked top 3 for three queries |
| 6. Code Quality | Named functions, comments, CLI, tests, this README, evidence logs |

## Short explanations

**Training vs inference:** Training fits model parameters using labeled examples. Inference applies a trained model to new, previously unseen text. The testing set is kept separate from training.

**Why preprocess text?** Normalizing casing, punctuation and whitespace reduces irrelevant variation. However, punctuation or case can carry meaning in some tasks, so preprocessing should suit the problem.

**Special tokens and subwords:** BERT uses `[CLS]` to mark the beginning and `[SEP]` to separate/end sequences. Subword tokenizers split rare words into reusable pieces instead of requiring one vocabulary entry per whole word. BERT and GPT-2 may tokenize the same sentence differently.

**Word counts vs embeddings:** Word counts measure token frequencies and mostly ignore meaning. Sentence embeddings represent text as dense numerical vectors designed to capture semantic relationships. Cosine similarity compares vector direction; a higher score suggests stronger semantic similarity, not a calibrated probability.

**Semantic search:** Encode the document collection once, encode each query, calculate cosine similarity and sort documents from highest to lowest score. The three sample queries cover course registration, tuition and account access.

## Testing and evidence

The `evidence/` folder contains genuine execution logs for the locally executable phases and unit tests. Transformer phases require the packages/models listed above; their outputs are **not** claimed to have been executed in the packaged environment. Run all phases on your own machine and capture screenshots of the console outputs for final submission if screenshots are required by your instructor.

This is a small educational demonstration; the dataset is not large enough to support real-world performance claims.
